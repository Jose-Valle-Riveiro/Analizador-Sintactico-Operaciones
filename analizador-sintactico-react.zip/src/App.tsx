import React, { useState } from "react";
import "./styles.css";
import axios from "axios";

export default function App() {
  const [inputCode, setInputCode] = useState<string>("");
  const [response, setResponse] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/analizar", {
        code: inputCode,
      });
      setResponse(res.data);
      setError(null);
    } catch (err) {
      setError("Ocurrió un error al analizar el código.");
      setResponse(null);
    }
  };

  return (
    <div className="container">
      <div className="box">
        <h1>Analizador Sintáctico</h1>
        <textarea
          placeholder="Ingrese el código fuente..."
          value={inputCode}
          onChange={(e) => setInputCode(e.target.value)}
        />
        <button onClick={handleSubmit}>Analizar</button>
        {error && <div className="error">{error}</div>}
        {response && (
          <pre className="resultado">{JSON.stringify(response, null, 2)}</pre>
        )}
      </div>
    </div>
  );
}
